// Biblioteca que será utilizada
#include <LiquidCrystal_I2C.h>
 
// Configuração: Endereço I2C, Colunas, Linhas
LiquidCrystal_I2C lcd(0x27, 16, 2);
 
void setup() {
// Configuração do número de linhas e colunas do LCD 
  lcd.begin(16, 2); // Nº de Colunas e Linhas do Display
  lcd.init(); // Inicializa o Display
  lcd.backlight(); // Liga o BackLight

}
 
void loop() {  
  lcd.setCursor(0,0); // Coluna 0, Linha 0
  lcd.print("Aula de SDMI");  // Insira seu texto Aqui
  delay(3000);  // Espera 3 segundos
  lcd.clear();  // Apaga o texto escrito no display
  lcd.setCursor(0,0); // Coluna 0, Linha 0
  lcd.print("Heitor");  // Insira seu texto Aqu
  delay(3000);  // Espera 3 segundos
  lcd.clear();  // Apaga o texto escrito no display
}